export default {
  transform: {},
  moduleFileExtensions: ["js", "mjs"],
  testEnvironment: "node",
  testMatch: ["**/*.test.js"],
};

