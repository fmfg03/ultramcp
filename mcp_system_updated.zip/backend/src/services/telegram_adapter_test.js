console.log('Telegram Adapter test file created');
